
class PromotionNotification {
  String image;
  String message;
  String datetime;

  PromotionNotification({
    this.image,
    this.message,
    this.datetime,
  });
}
