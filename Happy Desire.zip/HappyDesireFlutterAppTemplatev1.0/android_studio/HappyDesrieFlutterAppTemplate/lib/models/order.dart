class Order {
  String number;
  String date;
  String status;
  double totPrice;

  Order({
    this.number,
    this.date,
    this.status,
    this.totPrice,
  });
}
