class Address {
  String title;
  String subtitle;
  bool selected;

  Address({
    this.title,
    this.subtitle,
    this.selected,
  });
}
