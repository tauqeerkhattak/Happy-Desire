class Product {
  int id;
  String name;
  String image;
  double price;
  double discountPrice;
  int quantity;

  Product({
    this.id,
    this.name,
    this.image,
    this.price,
    this.discountPrice,
    this.quantity,
  });
}
