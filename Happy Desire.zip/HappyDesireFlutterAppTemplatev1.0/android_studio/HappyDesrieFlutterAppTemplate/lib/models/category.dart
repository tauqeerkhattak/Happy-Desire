class Category {
  int id;
  String name;
  String image;

  Category({
    this.id,
    this.name,
    this.image,
  });
}
