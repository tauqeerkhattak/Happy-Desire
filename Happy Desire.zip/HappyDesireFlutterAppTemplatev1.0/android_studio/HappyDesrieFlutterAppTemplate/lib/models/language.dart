class Language {
  String language;
  String icon;
  bool selected;

  Language({
    this.language,
    this.icon,
    this.selected,
  });
}
