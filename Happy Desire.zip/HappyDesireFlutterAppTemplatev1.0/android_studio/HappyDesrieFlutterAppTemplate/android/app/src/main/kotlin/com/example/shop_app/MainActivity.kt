package com.example.happydesire

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
